$(document).ready(function(){
/*	
	$("#attendance_entry").click(function(){
		//var now = new Date();
		//var time = now.getHours()+':'+now.getMinutes()+':'+now.getSeconds();
var time = $("#server_time").val();
//alert(time)
var postData = {
  'time' : time
}
 $.post('http://localhost/fedobe_erp/index.php/user/attendance/insert_entry_time', postData, function(data){			  
			  alert(data)
			  });  
		//$("#attendance_entry").hide();
		
	
	})*/
})

