<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<title>BHABANI FLY ASH BRICKS</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<meta name="apple-mobile-web-app-capable" content="yes">

<link href="<?= base_url();?>/assets/css/bootstrap.min.css" rel="stylesheet">

<link href="<?= base_url();?>/assets/css/bootstrap-responsive.min.css" rel="stylesheet">
<!--
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"

        rel="stylesheet">-->

<link href="<?= base_url();?>/assets/css/font-awesome.css" rel="stylesheet">

<link href="<?= base_url();?>/assets/css/style.css" rel="stylesheet">

<link href="<?= base_url();?>/assets/css/pages/dashboard.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->

<!--[if lt IE 9]>

      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

    <![endif]-->
	<script src="<?= base_url();?>/assets/js/jquery-1.7.2.min.js"></script>
<!-- <script src="<?= base_url();?>assets/datepicker/jquery-1.10.2.js"></script>-->
</head>

<body>

<div class="navbar navbar-fixed-top">

  <div class="navbar-inner">

    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span

                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="<?= site_url('admin/admin/index'); ?>"><!--<img  style="width:150px !important" src="<?= base_url();?>/assets/img/logo.png"   />-->BHABANI FLY ASH BRICKS </a>

      <div class="nav-collapse">

        <ul class="nav pull-right">

          <!--<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i

                            class="icon-cog"></i> Account <b class="caret"></b></a>

            <ul class="dropdown-menu">

              <li><a href="javascript:;">Settings</a></li>

              <li><a href="javascript:;">Help</a></li>

            </ul>

          </li>-->

          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i

                            class="icon-user"></i>
							<?php $data =  $this->session->userdata('identity'); ?>

							 <?php echo $data; ?> <b class="caret"></b></a>

            <ul class="dropdown-menu">

              <li><a href="javascript:;">Profile</a></li>
		<li><a href="<?= site_url('admin/auth/change_password'); ?>">Change Password</a></li>

              <li><a href="<?= site_url('admin/auth/logout'); ?>">Logout</a></li>

            </ul>

          </li>

        </ul>

      <!--  <form class="navbar-search pull-right">

          <input type="text" class="search-query" placeholder="Search">

        </form>-->

      </div>

      <!--/.nav-collapse -->

    </div>

    <!-- /container -->

  </div>

  <!-- /navbar-inner -->

</div>

<!-- /navbar -->

<?php
	$sesdata = $this->session->userdata;
	$group = $sesdata['group'];
	$menus = $this->common_model->get_menu($group);


?>

<div class="subnavbar">

  <div class="subnavbar-inner">

    <div class="container">

      <ul class="mainnav">

        <li class="active"><a href="<?= site_url('admin/admin/index'); ?>"><i class="icon-dashboard"></i><span>Dashboard</span> </a> </li>


<?php if($group==1){  ?>
<li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>SETTINGS</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

			<!--	<li><a href="<?= site_url('admin/auth/'); ?>"><span>User</span> </a></li>
				<li><a href="<?= site_url('admin/branch/index'); ?>"><span>Branch</span> </a></li>
								<li><a href="<?= site_url('admin/branch/create_branch'); ?>"><span>Create Branch</span> </a></li> -->

				<li><a href="<?= site_url('admin/material'); ?>"><span>MATERIAL</span> </a></li>
				<li><a href="<?= site_url('admin/product'); ?>"><span>PRODUCT</span> </a></li>

				</ul>
				</li>
<?php }  ?>


	   <?php if($group==2){  ?>
 <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>Production</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

				<li><a href="<?= site_url('admin/production/adminproduction'); ?>"><span>View Production</span> </a></li>
				<li><a href="<?= site_url('admin/production/create_production'); ?>"><span>Add Production</span> </a></li>

				</ul>
				</li>
<?php }  ?>

<?php if($group==1){  ?>
	   <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>PRODUCTION</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

				<li><a href="<?= site_url('admin/production/'); ?>"><span>VIEW PRODUCTION</span> </a></li>
				<li><a href="<?= site_url('admin/production/create_production'); ?>"><span>ADD PRODUCTION</span> </a></li>
				</ul>
				</li>

				<?php }  ?>

	   <?php if($group==2){  ?>
	   <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>Sales</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

				<li><a href="<?= site_url('admin/sales/index/'); ?>"><span>Add Sales</span> </a></li>
				<li><a href="<?= site_url('admin/sales/view_sales'); ?>"><span>View Sales</span> </a></li>
				<li><a href="<?= site_url('admin/sales/create_customer'); ?>"><span>View Customer</span> </a></li>
				<li><a href="<?= site_url('admin/sales/customer'); ?>"><span>Add Customer </span> </a></li>
				</ul>
				</li>



			<?php }  ?>






			<?php if($group==1){  ?>
	 <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>SALES</span> <b class="caret"></b></a>
			<ul class="dropdown-menu">
				<li><a href="<?= site_url('admin/sales/index/'); ?>"><span>NEW SALES </span> </a></li>
			<li><a href="<?= site_url('admin/sales/admin_sales'); ?>"><span>VIEW  SALES</span> </a></li>
			<li><a href="<?= site_url('admin/sales/create_customer'); ?>"><span>ADD  CUSTOMER</span> </a></li>
			<li><a href="<?= site_url('admin/sales/customer'); ?>"><span>VIEW CUSTOMER</span> </a></li>
			<li><a href="<?= site_url('admin/sales/summery'); ?>"><span>SALES SUMMERY </span> </a></li>
			</ul>
			</li>

		<?php }  ?>



		<?php if($group==1){  ?>
 <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>PAYMENT COLLECTION</span> <b class="caret"></b></a>
		<ul class="dropdown-menu">
		<li><a href="<?= site_url('admin/sales/view_payment'); ?>"><span> VIEW PAYMENT </span> </a></li>
		<li><a href="<?= site_url('admin/sales/add_payment'); ?>"><span> NEW PAYMENT </span> </a></li>
			<li><a href="<?= site_url('admin/sales/report'); ?>"><span>PAYMENT REPORT </span> </a></li>
		</ul>
		</li>

	<?php }  ?>





			<li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>PURCHASE</span> <b class="caret"></b></a>
				 <ul class="dropdown-menu">

				 <li><a href="<?= site_url('admin/account/'); ?>"><span>NEW PURCHASE</span> </a></li>
				 <li><a href="<?= site_url('admin/account/view_account'); ?>"><span>VIEW PURCHASE</span> </a></li>
				 <li><a href="<?= site_url('admin/account/create_party'); ?>"><span>ADD PARTY </span> </a></li>
				 <li><a href="<?= site_url('admin/account/party'); ?>"><span>VIEW PARTY </span> </a></li>

				 <li><a href="<?= site_url('admin/account/view_payment'); ?>"><span> VIEW PAYMENT </span> </a></li>
				 <li><a href="<?= site_url('admin/account/add_payment'); ?>"><span> NEW PAYMENT  </span> </a></li>
				 <li><a href="<?= site_url('admin/account/report'); ?>"><span>PAYMENT  REPORT </span> </a></li>
				 </ul>
				 </li>





				 <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>Stock</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

				<li><a href="<?= site_url('admin/stock/index/'); ?>"><span>Brick Stock</span> </a></li>
				<li><a href="<?= site_url('admin/stock/material'); ?>"><span>Material Stock</span> </a></li>
				</ul>
				</li>





<?php  if(in_array("Manage Question", $menus)){ ?>




	<?php } ?>















<!--<li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list-alt"></i><span>Account</span> <b class="caret"></b></a>
				<ul class="dropdown-menu">

				<li><a href="<?= site_url('admin/account/party'); ?>"><span>Create Account</span> </a></li>
				<li><a href="<?= site_url('admin/account/view_account'); ?>"><span>Create Voucher</span> </a></li>
		<li><a href="<?= site_url('admin/account/report'); ?>"><span>View Account Report</span> </a></li>
		<li><a href="<?= site_url('admin/account/misc_acc'); ?>"><span>Finance Report</span> </a></li>
	<li><a href="<?= site_url('admin/account/finance'); ?>"><span>Finance All Report</span> </a></li>
		</ul>
				</li>-->



								        <li class="active"><a  class="btn-success" href="<?= site_url('admin/sales/credit'); ?>"><i class="icon-list-alt"></i><span>CREDIT REPORT</span> </a> </li>



      </ul>

    </div>

    <!-- /container -->

  </div>

  <!-- /subnavbar-inner -->

</div>
