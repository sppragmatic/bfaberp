<div class="extra">

  <div class="extra-inner">

    <div class="container">

    

      <!-- /row --> 

    </div>

    <!-- /container --> 

  </div>

  <!-- /extra-inner --> 

</div>

<!-- /extra -->

<div class="footer">

  <div class="footer-inner">

    <div class="container">

      <div class="row">

        <div class="span12"> &copy; 2017 <a href="http://praits.org">Pragmatic Infosystems</a>. </div>

        <!-- /span12 --> 

      </div>

      <!-- /row --> 

    </div>

    <!-- /container --> 

  </div>

  <!-- /footer-inner --> 

</div>

<!-- /footer --> 

<!-- Le javascript

================================================== --> 

<!-- Placed at the end of the document so the pages load faster --> 



<!-- <script src="<?= base_url();?>/assets/js/excanvas.min.js"></script>  -->

<!-- <script src="<?= base_url();?>/assets/js/chart.min.js" type="text/javascript"></script> -->

<script src="<?= base_url();?>/assets/js/bootstrap.js"></script>

<!--<script language="javascript" type="text/javascript" src="<?= base_url();?>/assets/js/full-calendar/fullcalendar.min.js"></script>

 -->

 <!-- <script src="<?= base_url();?>/assets/js/base.js"></script>  -->

</body>

</html>

